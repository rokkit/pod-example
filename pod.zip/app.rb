require 'sinatra'

puts "Hello from CloudPod"

get '/me' do
  "Response from CloudPod"
end
